﻿namespace ClashN.Mode
{
    public enum CoreKind
    {
        Clash = 1,
        ClashMeta = 2,
        ClashPremium = 3,
        ClashN = 99
    }
}