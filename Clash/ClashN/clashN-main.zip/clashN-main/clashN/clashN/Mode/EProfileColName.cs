﻿namespace ClashN.Mode
{
    public enum EProfileColName
    {
        def = 0,
        remarks,
        url,
        address,
        enableUpdateSub,
        testResult,
        updateTime,

        todayDown,
        todayUp,
        totalDown,
        totalUp
    }
}