﻿namespace ClashN.Mode
{
    public enum ERuleMode
    {
        Rule = 0,
        Global = 1,
        Direct = 2,
        Unchanged = 3
    }
}