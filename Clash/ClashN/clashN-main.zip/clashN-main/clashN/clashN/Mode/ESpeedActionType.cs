﻿namespace ClashN.Mode
{
    public enum ESpeedActionType
    {
        Ping,
        Tcping,
        Realping,
        Speedtest
    }
}