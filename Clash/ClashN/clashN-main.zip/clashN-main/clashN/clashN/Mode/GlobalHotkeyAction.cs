﻿namespace ClashN.Mode
{
    public enum GlobalHotkeyAction
    {
        ShowForm = 0,
        SystemProxyClear = 1,
        SystemProxySet = 2,
        SystemProxyUnchanged = 3,
        SystemProxyPac = 4,
    }
}