﻿namespace ClashN.Mode
{
    public enum MovementTarget
    {
        Top = 1,
        Up = 2,
        Down = 3,
        Bottom = 4,
        Position = 5
    }
}