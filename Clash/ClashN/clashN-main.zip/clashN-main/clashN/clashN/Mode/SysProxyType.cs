﻿namespace ClashN.Mode
{
    public enum SysProxyType
    {
        ForcedClear = 0,
        ForcedChange = 1,
        Unchanged = 2,
        Pac = 3
    }
}