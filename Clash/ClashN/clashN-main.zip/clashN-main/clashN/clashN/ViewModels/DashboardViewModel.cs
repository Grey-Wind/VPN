using ReactiveUI;

namespace ClashN.ViewModels
{
    public class DashboardViewModel : ReactiveObject
    {
        public DashboardViewModel()
        {
        }
    }
}