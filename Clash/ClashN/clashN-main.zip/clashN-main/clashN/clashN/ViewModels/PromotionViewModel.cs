using ReactiveUI;

namespace ClashN.ViewModels
{
    public class PromotionViewModel : ReactiveObject
    {
        public PromotionViewModel()
        {
        }
    }
}