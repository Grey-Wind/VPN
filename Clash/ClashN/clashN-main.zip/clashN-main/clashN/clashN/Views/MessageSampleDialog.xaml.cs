﻿using System.Windows.Controls;

namespace ClashN.Views
{
    /// <summary>
    /// Interaction logic for MessageSampleDialog.xaml
    /// </summary>
    public partial class MessageSampleDialog : UserControl
    {
        public MessageSampleDialog()
        {
            InitializeComponent();
        }
    }
}