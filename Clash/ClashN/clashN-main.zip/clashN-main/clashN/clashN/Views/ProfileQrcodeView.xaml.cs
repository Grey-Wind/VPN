﻿using System.Windows.Controls;

namespace ClashN.Views
{
    /// <summary>
    /// Interaction logic for ProfileQrcodeView.xaml
    /// </summary>
    public partial class ProfileQrcodeView : UserControl
    {
        public ProfileQrcodeView()
        {
            InitializeComponent();
        }
    }
}