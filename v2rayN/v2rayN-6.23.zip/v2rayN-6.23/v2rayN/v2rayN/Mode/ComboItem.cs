﻿namespace v2rayN.Mode
{
    public class ComboItem
    {
        public string ID
        {
            get; set;
        }

        public string Text
        {
            get; set;
        }
    }
}