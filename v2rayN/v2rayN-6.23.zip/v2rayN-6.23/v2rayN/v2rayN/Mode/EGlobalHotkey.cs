﻿namespace v2rayN.Mode
{
    public enum EGlobalHotkey
    {
        ShowForm = 0,
        SystemProxyClear = 1,
        SystemProxySet = 2,
        SystemProxyUnchanged = 3,
        SystemProxyPac = 4,
    }
}