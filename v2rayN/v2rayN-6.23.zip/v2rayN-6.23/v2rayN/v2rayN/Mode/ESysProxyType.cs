﻿namespace v2rayN.Mode
{
    public enum ESysProxyType
    {
        ForcedClear = 0,
        ForcedChange = 1,
        Unchanged = 2,
        Pac = 3
    }
}