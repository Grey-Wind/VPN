﻿namespace v2rayN.Mode
{
    public enum EViewAction
    {
        AdjustMainLvColWidth,
        ProfilesFocus
    }
}