﻿using System.Windows.Controls;

namespace v2rayN.Views
{
    public partial class QrcodeView : UserControl
    {
        public QrcodeView()
        {
            InitializeComponent();
        }
    }
}